.. index file for optional plugins

================
Optional Plugins
================

The following pages are the documentation for some of the Avocado
optional plugins:

.. toctree::
   :maxdepth: 1

   results
   robot
   varianter_yaml_to_mux
   varianter_pict
   yaml_loader
   golang
