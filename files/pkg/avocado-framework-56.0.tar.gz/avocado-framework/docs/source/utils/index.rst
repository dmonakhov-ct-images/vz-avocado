.. index file for utilities

=========
Utilities
=========

The following pages are the documentation for some of the Avocado
utilities:

.. toctree::
   :maxdepth: 1

   vmimage
