#include <stdlib.h>

int
main(void)
{
	abort();
}
