#include <stdio.h>

int main()
{
  int *p = NULL;
  *p = 0xdead;

  return 0;
}
